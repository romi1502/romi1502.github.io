This archive file contains the database used to evaluate score informed source separation algorithms.
This database contains :
- MIDI files of 12 quartets by Bach, Beethoven and Boccherini
- sound files synthesized from these MIDI files with two different methods (referred as "method 1 - isolated notes" and "method 2 - Crisis General MIDI").

The sound files correspond to the synthesis of each track of the MIDI file (remark : track 1 in the MIDI files is a track containing general information about the MIDI files and does not correspond to an instrument. Thus it is not synthesized). There is also a mixture signal for each MIDI files which is the sum of the different tracks.